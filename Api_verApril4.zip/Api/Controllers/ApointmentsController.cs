﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Api.Hubs;
using Api.Models;
using Api.Models.Transport;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;

namespace Api.Controllers
{
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Produces("application/json")]
    [Route("api/Apointments")]
    public class ApointmentsController : Controller
    {
        private bcareContext context;
        private IHubContext<NotificationHub> hubContext;

        public ApointmentsController(bcareContext context, IHubContext<NotificationHub> hubContext)
        {
            this.context = context;
            this.hubContext = hubContext;
        }


        [HttpGet]
        public IActionResult Apointments()
        {
            var apointments = this.context.Apointment
                .Include(e => e.Diagnosis)
                .Include(e => e.FkPatient)
                .ToList();

            return Ok(new ResponseResult<List<Apointment>>
            {
                Status = ResponseResultStatus.Ok,
                Body = apointments
            });
        }

        //rejected , approved filter done in UI
        [HttpGet("open")]
        public IActionResult OpenApointments()
        {
            var dateNow = DateTime.Now;
            var date = new DateTime(dateNow.Year, dateNow.Month, dateNow.Day);

            var apointments = this.context.Apointment
                .Include(e => e.Diagnosis)
                .Include(e => e.FkPatient)
                .Where(e =>  e.IsClosed == false )
                //.Where(e => e.IsClosed == false && (e.ApointmentDate >= date))
                //.OrderByDescending(e => e.ApointmentDate)
                .OrderBy(e => e.ApointmentDate)
                .ToList();

            return Ok(new ResponseResult<List<Apointment>>
            {
                Status = ResponseResultStatus.Ok,
                Body = apointments
            });
        }

        [HttpGet("{id}")]
        public IActionResult Apointments(Guid id)
        {
            var apointment = this.context.Apointment
                .Include(e => e.Diagnosis)
                .Include(e => e.FkPatient)
                .FirstOrDefault(e => e.PkApointmentId == id);

            return Ok(new ResponseResult<Apointment>
            {
                Status = ResponseResultStatus.Ok,
                Body = apointment
            });
        }

        [HttpGet("Patient/{id}")]
        public IActionResult PatientApointments(Guid id)
        {
            var apointments = this.context.Apointment
                .Include(e => e.Diagnosis)
                .Include(e => e.FkPatient)
                .Where(e => e.FkPatientId == id)
                .OrderBy(e => e.ApointmentDate)
                //.OrderByDescending(e => e.ApointmentDate)
                .ToList();

            return Ok(new ResponseResult<List<Apointment>>
            {
                Status = ResponseResultStatus.Ok,
                Body = apointments
            });
        }

        [HttpPost]
        public IActionResult Create([FromBody] Apointment apointment)
        {
            this.context.Apointment.Add(apointment);
            this.context.SaveChanges();

            this.hubContext.Clients.All.SendAsync("AppointmentCreated", new
            {
                AppointmentId = apointment.PkApointmentId,
                PatientId = apointment.FkPatientId
            });

            return Ok(new ResponseResult<Guid>
            {
                Status = ResponseResultStatus.Ok,
                Body = apointment.PkApointmentId
            });
        }

        [HttpPut]
        public IActionResult Update([FromBody] Apointment apointment)
        {
            if ( apointment.IsClosed)
                apointment.ClosingDate = DateTime.Now;

            this.context.Apointment.Update(apointment);
            this.context.SaveChanges();

            return Ok(new ResponseResult<Guid>
            {
                Status = ResponseResultStatus.Ok,
                Body = apointment.PkApointmentId
            });
        }

        [HttpPost("Sms")]
        public IActionResult SendSMS([FromBody] MessageModel fkMessage)
        {
            fkMessage.PkMessageId = Guid.NewGuid();

            //TR-SONNY136939_EMLE4
            try
            {
                foreach(var personid in fkMessage.Contactlist)
                {
                    var person = this.context.Person.Where(p => p.PkPersonId == personid).FirstOrDefault();
                    if ( person != null && !string.IsNullOrEmpty(person.ContactNo))
                    {
                        var thisnumber = person.ContactNo.Replace("-", "").Replace("+63","0").Replace(" ","");
                        itexmo(thisnumber, fkMessage.Message);

                        //if ( IsPhoneNumber(thisnumber))
                        //{
                        //    itexmo(thisnumber, fkMessage.Message);
                        //}
                    }
                }

                return Ok(new ResponseResult<Guid>
                {
                    Status = ResponseResultStatus.Ok,
                    Body = fkMessage.PkMessageId
                });
            }
            catch(Exception ex)
            {
                return Ok(new ResponseResult<Guid>
                {
                    Status = ResponseResultStatus.Ok,
                    Body = fkMessage.PkMessageId,
                    Message = ex.Message
                });
            }

            
        }

        public object itexmo(string Number, string Message, string API_CODE = "TR-SONNY136939_EMLE4")
        {
            object functionReturnValue = null;
            using (System.Net.WebClient client = new System.Net.WebClient())
            {
                System.Collections.Specialized.NameValueCollection parameter = new System.Collections.Specialized.NameValueCollection();
                string url = "https://www.itexmo.com/php_api/api.php";
                parameter.Add("1", Number);
                parameter.Add("2", Message);
                parameter.Add("3", API_CODE);
                dynamic rpb = client.UploadValues(url, "POST", parameter);
                functionReturnValue = (new System.Text.UTF8Encoding()).GetString(rpb);
            }
            return functionReturnValue;
        }

        public bool IsPhoneNumber(string number)
        {
            return Regex.Match(number, @"^(\[0-9]{11})$").Success;
        }

    }


}