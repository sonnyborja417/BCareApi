﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Api.Models;
using Api.Models.Transport;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Api.Controllers
{
    [Produces("application/json")]
    [Route("api/Reports")]
    public class ReportsController : Controller
    {
        private bcareContext context;

        public ReportsController(bcareContext context)
        {
            this.context = context;
        }

        [HttpGet("Monthly/Diagnosis/{date}")]
        public IActionResult MonthlyDiagnosis([FromRoute] DateTime date)
        {
            var dFrom = new DateTime(date.Year, date.Month, 1);
            var dTo = dFrom.AddMonths(1);

            var appointments = this.context.Apointment
                .Include(e => e.FkPatient)
                .Include(e => e.Diagnosis)
                //.Where(e => (e.ApointmentDate >= dFrom && e.ApointmentDate < dTo) && e.IsClosed)
                .Where(e => (e.ClosingDate >= dFrom && e.ClosingDate < dTo) && e.IsClosed)
                .ToList();

            List<(string Name, int Count)> pieData = appointments.SelectMany(e => e.Diagnosis).GroupBy(e => e.Name.ToUpper()).Select(group =>
            {
                return (group.Key, group.Count());
            }).ToList();

            List<(int day, int total)> lineData = new List<(int day, int total)>();
            List<(int age, int total)> barData = new List<(int age, int total)>();

            for (var index = 1; index <= dTo.AddDays(-1).Day; index++)
            {
                var data = appointments.Count(e => e.IsApproved && e.ApointmentDate.Day == index);
                

                lineData.Add((index, data));
            }

            foreach (var ageGroup in appointments.Where(e => e.IsApproved).GroupBy(e => e.FkPatient.DoB))
            {
                if (ageGroup.Key == null) continue;

                var age = DateTime.Now.Year - ((DateTime)ageGroup.Key).Year;

                barData.Add((age, ageGroup.Count()));
            }

            //List<(string Name, Guid patientId, DateTime Date, string Diagnosis, Guid Id)> tableData =  appointments.Select(appointment => 
            //{
            //    var p = appointment.FkPatient;
            //    var d = string.Join(",", appointment.Diagnosis.Select(e => e.Name));

            //    return (p.FullName, p.PkPersonId, (DateTime)appointment.ApointmentDate, d, appointment.PkApointmentId);
            //}).ToList();
            List<(string Name, Guid patientId, DateTime Date, string Diagnosis, Guid Id, string Symptom, string Notes)> tableData = appointments.Select(appointment =>
            {
                var p = appointment.FkPatient;
                //var d = string.Join(",", appointment.Diagnosis.Select(e => e.Name));

                return (p.FullName, p.PkPersonId, (DateTime)appointment.ApointmentDate, appointment.Diagnosy
                    , appointment.PkApointmentId, appointment.PatientSymptoms, appointment.DoctorsNotes );
            }).ToList();

            return Ok(new ResponseResult<object>
            {
                Status = ResponseResultStatus.Ok,
                Body = new {
                    Table = tableData,
                    //Pie = pieData,
                    //line = lineData,
                    //bar = barData
                }
            });
        }

        [HttpGet("Monthly/Summary/{date}")]
        public IActionResult MonthlySummary([FromRoute] DateTime date)
        {
            var dFrom = new DateTime(date.Year, date.Month, 1);
            var dTo = dFrom.AddMonths(1);

            var appointments = this.context.Apointment
                .Include(e => e.FkPatient)
                .Include(e => e.Diagnosis)                
                .Where(e => (e.ApointmentDate >= dFrom && e.ApointmentDate < dTo) )
                .ToList();

            var data = new
            {
                Total = appointments.Count(),
                Closed = appointments.Where(a=>a.IsClosed).Count(),
                PendingApproval = appointments.Where(a => a.IsApproved == false && a.IsRejected == false &&  a.IsClosed == false).Count(),
                Rejected = appointments.Where(a => a.IsRejected  ).Count()
            };                                

            return Ok(new ResponseResult<object>
            {
                Status = ResponseResultStatus.Ok,
                Body = new
                {
                    Table = data                    
                }
            });
        }

        [HttpGet("Monthly/Rejected/{date}")]
        public IActionResult MonthlyRejected([FromRoute] DateTime date)
        {
            var dFrom = new DateTime(date.Year, date.Month, 1);
            var dTo = dFrom.AddMonths(1);

            var appointments = this.context.Apointment
                .Include(e => e.FkPatient)
                .Include(e => e.Diagnosis)
                .Where(e => (e.ApointmentDate >= dFrom && e.ApointmentDate < dTo) && e.IsRejected )
                .ToList();            

            return Ok(new ResponseResult<object>
            {
                Status = ResponseResultStatus.Ok,
                Body = new
                {
                    Table = appointments
                }
            });
        }
    }
}