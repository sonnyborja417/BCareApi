﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Models.Transport
{
    public static class ResponseResultStatus
    {
        public static readonly string Ok = "OK";
        public static readonly string Error = "ERROR";
    }
}
